import React from 'react';
import './yellow.css';

const Yellow=()=>{
    return (
        <div id='amarillo'>
        </div>
    )
}

export default Yellow;