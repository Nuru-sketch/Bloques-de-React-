import React from "react";
import './bluesky.css'

const BlueSky=()=>{
    return (
        <div id="boxsky">
        </div>
    )
}

export default BlueSky;